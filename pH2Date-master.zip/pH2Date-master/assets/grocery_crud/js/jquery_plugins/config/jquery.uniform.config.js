$(function () {
    $(".radio-uniform").uniform();
});
