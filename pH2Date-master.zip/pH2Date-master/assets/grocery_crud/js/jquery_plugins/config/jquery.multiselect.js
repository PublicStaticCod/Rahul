$(function () {
    $(".multiselect").multiselect();
});
